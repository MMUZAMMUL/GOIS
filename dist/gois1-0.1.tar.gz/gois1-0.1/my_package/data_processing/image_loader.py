def load_image(image_path):
    """Dummy function to load an image."""
    print(f"Loading image from {image_path}...")
    return None  # Placeholder for loaded image
